package ua.paladin;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import ua.paladin.ability.Blessing;
import ua.paladin.ability.SacredProtection;
import ua.paladin.ability.SmiteListener;
import ua.paladin.ability.SmiteManager;
import ua.paladin.clazz.BrawlerLink;
import ua.paladin.clazz.ClassManager;
import ua.paladin.command.ClassCommand;
import ua.paladin.command.PaladinCommand;
import ua.paladin.data.DataStore;
import ua.paladin.gui.Menus;
import ua.paladin.listener.PlayerListener;
import ua.paladin.team.TeamManager;
import ua.paladin.util.Fx;
import ua.paladin.util.Msg;

public final class PaladinPlugin extends JavaPlugin {
    private Msg msg;
    private Fx fx;
    private DataStore store;
    private BrawlerLink brawler;
    private ClassManager classes;
    private TeamManager teams;
    private SmiteManager smite;
    private Blessing blessing;
    private Menus menus;
    private PlayerListener playerListener;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        msg = new Msg(this);
        fx = new Fx(this);
        fx.reload();
        store = new DataStore(this);
        store.load();
        brawler = new BrawlerLink(this);
        teams = new TeamManager(this);
        smite = new SmiteManager(this);
        classes = new ClassManager(this);
        teams.load();
        blessing = new Blessing(this);
        blessing.reload();
        menus = new Menus(this);
        playerListener = new PlayerListener(this);

        Bukkit.getPluginManager().registerEvents(new SacredProtection(this), this);
        Bukkit.getPluginManager().registerEvents(blessing, this);
        Bukkit.getPluginManager().registerEvents(new SmiteListener(this), this);
        Bukkit.getPluginManager().registerEvents(menus, this);
        Bukkit.getPluginManager().registerEvents(playerListener, this);

        ClassCommand classCmd = new ClassCommand(this);
        PluginCommand pc = getCommand("paladinclass");
        if (pc != null) {
            pc.setExecutor(classCmd);
            pc.setTabCompleter(classCmd);
        }
        PaladinCommand paladinCmd = new PaladinCommand(this);
        PluginCommand pl = getCommand("paladin");
        if (pl != null) {
            pl.setExecutor(paladinCmd);
            pl.setTabCompleter(paladinCmd);
        }

        smite.start();
        for (Player p : Bukkit.getOnlinePlayers()) playerListener.handleJoin(p);
    }

    @Override
    public void onDisable() {
        if (smite != null) smite.shutdown();
        if (teams != null) teams.shutdown();
        if (store != null) store.save();
    }

    public void reloadAll() {
        reloadConfig();
        fx.reload();
        blessing.reload();
        smite.updateAllHud();
    }

    public Msg msg() { return msg; }
    public Fx fx() { return fx; }
    public DataStore store() { return store; }
    public BrawlerLink brawler() { return brawler; }
    public ClassManager classes() { return classes; }
    public TeamManager teams() { return teams; }
    public SmiteManager smite() { return smite; }
    public Menus menus() { return menus; }
}
