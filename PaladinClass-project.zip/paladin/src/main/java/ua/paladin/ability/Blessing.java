package ua.paladin.ability;

import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import ua.paladin.PaladinPlugin;
import ua.paladin.util.Range;
import ua.paladin.util.Shield;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** «Благословення»: позитивні ефекти Паладіна отримують і його союзники поблизу. */
public final class Blessing implements Listener {
    private final PaladinPlugin plugin;
    private final Set<PotionEffectType> positive = new HashSet<>();
    /** Захист від циклу: ефекти, видані цією здібністю, не запускають нову передачу. */
    private boolean sharing;

    public Blessing(PaladinPlugin plugin) { this.plugin = plugin; }

    public void reload() {
        positive.clear();
        for (String key : plugin.getConfig().getStringList("abilities.blessing.beneficial-effects")) {
            String k = key.trim().toLowerCase();
            if (k.startsWith("minecraft:")) k = k.substring("minecraft:".length());
            PotionEffectType t = PotionEffectType.getByKey(NamespacedKey.minecraft(k));
            if (t == null) {
                plugin.getLogger().warning("Невідомий ефект у beneficial-effects: " + key);
            } else {
                positive.add(t);
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEffect(EntityPotionEffectEvent e) {
        if (sharing) return;
        if (!(e.getEntity() instanceof Player paladin)) return;
        EntityPotionEffectEvent.Action action = e.getAction();
        if (action != EntityPotionEffectEvent.Action.ADDED && action != EntityPotionEffectEvent.Action.CHANGED) return;
        PotionEffect eff = e.getNewEffect();
        if (eff == null || !positive.contains(eff.getType())) return;

        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("abilities.blessing.enabled", true)) return;
        UUID id = paladin.getUniqueId();
        if (!plugin.classes().isPaladin(id) || !plugin.teams().isLeader(id)) return;
        if (c.getBoolean("abilities.blessing.require-shield", true) && !Shield.inOffHand(paladin)) return;

        double radius = c.getDouble("abilities.blessing.radius", 10.0);
        String effName = eff.getType().getKey().getKey();
        String level = String.valueOf(eff.getAmplifier() + 1);
        boolean any = false;
        sharing = true;
        try {
            for (Player ally : plugin.teams().onlineMembers(id)) {
                if (ally.isDead() || !Range.within(paladin, ally, radius)) continue;
                // addPotionEffect оновлює ефект, якщо він сильніший або довший за наявний
                ally.addPotionEffect(eff);
                plugin.fx().spawn("blessing", ally.getLocation().add(0, 1, 0), 15, 0.4, 0.6, 0.4, 0.02);
                plugin.msg().bar(ally, "blessing-received", "effect", effName, "level", level);
                any = true;
            }
        } finally {
            sharing = false;
        }
        if (any) plugin.fx().sound(paladin.getLocation(), "blessing", 0.6f, 1.4f);
    }
}
