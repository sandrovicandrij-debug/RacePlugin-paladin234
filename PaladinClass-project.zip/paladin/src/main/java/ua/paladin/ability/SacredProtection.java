package ua.paladin.ability;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import ua.paladin.PaladinPlugin;
import ua.paladin.util.Range;
import ua.paladin.util.Shield;

import java.util.EnumSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/** «Священний захист»: Паладін приймає шкоду союзників (x1.5), поки щит у лівій руці. */
public final class SacredProtection implements Listener {
    private static final Set<DamageCause> SKIP = EnumSet.of(
            DamageCause.VOID, DamageCause.KILL, DamageCause.SUICIDE, DamageCause.WORLD_BORDER);

    private final PaladinPlugin plugin;
    /** Захист від рекурсії: поки йде перенесення, нові перенесення не запускаються. */
    private boolean sharing;

    public SacredProtection(PaladinPlugin plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (sharing) return;
        if (!(e.getEntity() instanceof Player ally)) return;
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("abilities.sacred-protection.enabled", true)) return;
        if (SKIP.contains(e.getCause())) return;

        UUID leaderId = plugin.teams().leaderOf(ally.getUniqueId());
        if (leaderId == null) return; // лише союзники; сам Паладін ніколи не переносить шкоду
        if (!plugin.classes().isPaladin(leaderId)) return;
        Player paladin = Bukkit.getPlayer(leaderId);
        if (paladin == null || !paladin.isOnline() || paladin.isDead()) return;
        if (c.getBoolean("abilities.sacred-protection.require-shield", true) && !Shield.inOffHand(paladin)) return;
        if (!Range.within(ally, paladin, c.getDouble("abilities.sacred-protection.radius", 10.0))) return;
        if (e instanceof EntityDamageByEntityEvent byEntity && damagerIs(byEntity, paladin)) return;

        double dmg = e.getFinalDamage();
        if (dmg <= 0) return; // шкоду вже повністю скасовано іншим ефектом чи блоком
        double amount = dmg * c.getDouble("abilities.sacred-protection.damage-multiplier", 1.5);

        e.setCancelled(true);
        sharing = true;
        try {
            paladin.setNoDamageTicks(0);
            paladin.damage(amount);
        } finally {
            sharing = false;
        }

        Location from = ally.getLocation().add(0, 1, 0);
        Location to = paladin.getLocation().add(0, 1, 0);
        plugin.fx().line("damage-transfer", from, to, 10);
        plugin.fx().spawn("damage-taken", to, 12, 0.3, 0.5, 0.3, 0.02);
        plugin.fx().sound(paladin.getLocation(), "damage-transfer", 0.8f, 1.1f);
        plugin.msg().bar(ally, "damage-shared-ally", "name", paladin.getName());
        plugin.msg().bar(paladin, "damage-shared-paladin",
                "amount", String.format(Locale.ROOT, "%.1f", amount), "name", ally.getName());
    }

    private static boolean damagerIs(EntityDamageByEntityEvent e, Player p) {
        Entity d = e.getDamager();
        if (d.equals(p)) return true;
        return d instanceof Projectile pr && pr.getShooter() instanceof Entity s && s.equals(p);
    }
}
