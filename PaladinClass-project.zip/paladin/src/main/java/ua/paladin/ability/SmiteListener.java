package ua.paladin.ability;

import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import ua.paladin.PaladinPlugin;

import java.util.Locale;

/** «Кара»: накопичення отриманої шкоди та додаткова шкода наступної успішної атаки. */
public final class SmiteListener implements Listener {
    private final PaladinPlugin plugin;

    public SmiteListener(PaladinPlugin plugin) { this.plugin = plugin; }

    /** Накопичуємо лише фактичну шкоду після всіх модифікаторів; скасовані події не враховуються. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamaged(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (!plugin.smite().enabled() || !plugin.classes().isPaladin(p.getUniqueId())) return;
        double dmg = e.getFinalDamage();
        if (dmg <= 0) return; // повністю заблоковано або скасовано
        plugin.smite().add(p, dmg);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent e) {
        if (!plugin.smite().enabled()) return;
        DamageCause cause = e.getCause();
        boolean projectile = cause == DamageCause.PROJECTILE;
        if (cause != DamageCause.ENTITY_ATTACK && !projectile) return; // не спрацьовує на sweep, шипи тощо
        if (projectile && !plugin.getConfig().getBoolean("abilities.smite.include-projectiles", true)) return;

        Player p = attacker(e);
        if (p == null || !plugin.classes().isPaladin(p.getUniqueId())) return;
        if (!plugin.smite().isReady(p.getUniqueId())) return;

        Entity victim = e.getEntity();
        if (victim.equals(p) || victim instanceof ArmorStand || !(victim instanceof LivingEntity target)) return;
        if (victim instanceof Player vp && plugin.teams().sameTeam(p.getUniqueId(), vp.getUniqueId())) return;

        double bonus = plugin.smite().bonus();
        // Спочатку витрачаємо Кару — повторна подія тієї ж атаки вже її не отримає
        plugin.smite().consume(p);
        e.setDamage(e.getDamage() + bonus);

        plugin.fx().spawn("smite-strike", target.getLocation().add(0, target.getHeight() / 2, 0), 40, 0.4, 0.6, 0.4, 0.15);
        plugin.fx().sound(target.getLocation(), "smite-strike", 1.0f, 1.0f);
        plugin.msg().bar(p, "smite-strike", "damage", String.format(Locale.ROOT, "%.0f", bonus));
    }

    private static Player attacker(EntityDamageByEntityEvent e) {
        Entity d = e.getDamager();
        if (d instanceof Player p) return p;
        if (d instanceof Projectile pr && pr.getShooter() instanceof Player p) return p;
        return null;
    }
}
