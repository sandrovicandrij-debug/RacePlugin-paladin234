package ua.paladin.ability;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import ua.paladin.PaladinPlugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Стан «Кари»: накопичення, BossBar, збільшення розміру, аура. */
public final class SmiteManager {
    private final PaladinPlugin plugin;
    private final Map<UUID, Double> accum = new HashMap<>();
    private final Map<UUID, BossBar> bars = new HashMap<>();
    private final Set<UUID> scaled = new HashSet<>();
    private BukkitTask task;
    private int tick;

    public SmiteManager(PaladinPlugin plugin) { this.plugin = plugin; }

    // ---------- налаштування ----------

    public boolean enabled() { return plugin.getConfig().getBoolean("abilities.smite.enabled", true); }

    public double max() { return Math.max(1.0, plugin.getConfig().getDouble("abilities.smite.max-accumulation", 100.0)); }

    public double bonus() { return plugin.getConfig().getDouble("abilities.smite.bonus-damage", 20.0); }

    private double scaleValue() { return Math.max(0.1, plugin.getConfig().getDouble("abilities.smite.scale-multiplier", 1.5)); }

    public boolean isReady(UUID id) { return accum.getOrDefault(id, 0.0) >= max(); }

    // ---------- життєвий цикл ----------

    public void start() {
        stop();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::run, 4L, 4L);
    }

    public void stop() {
        if (task != null) task.cancel();
        task = null;
    }

    /** Вимкнення плагіна: зберегти стан і повернути стандартний розмір усім. */
    public void shutdown() {
        stop();
        for (Player p : new ArrayList<>(Bukkit.getOnlinePlayers())) {
            if (plugin.classes().isPaladin(p.getUniqueId())) flush(p);
            restoreScale(p);
            hideHud(p);
        }
        plugin.store().save();
        accum.clear();
        bars.clear();
        scaled.clear();
    }

    /** Гравець зайшов: відновити накопичення, HUD та (за потреби) розмір. */
    public void onJoin(Player p) {
        UUID id = p.getUniqueId();
        restoreScale(p); // на випадок краху сервера, коли розмір залишився збільшеним
        if (!plugin.classes().isPaladin(id)) return;
        double v = plugin.store().smite().getOrDefault(id, 0.0);
        if (v > 0) accum.put(id, Math.min(v, max()));
        if (isReady(id)) tryScale(p);
        updateHud(p);
    }

    public void onQuit(Player p) {
        UUID id = p.getUniqueId();
        if (plugin.classes().isPaladin(id)) flush(p);
        restoreScale(p);
        hideHud(p);
        accum.remove(id);
        scaled.remove(id);
    }

    public void onDeath(Player p) {
        UUID id = p.getUniqueId();
        if (!plugin.classes().isPaladin(id)) return;
        accum.remove(id);
        plugin.store().smite().remove(id);
        restoreScale(p);
        updateHud(p);
    }

    public void onClassGained(Player p) {
        accum.remove(p.getUniqueId());
        plugin.store().smite().remove(p.getUniqueId());
        updateHud(p);
    }

    public void onClassLost(Player p) {
        UUID id = p.getUniqueId();
        accum.remove(id);
        plugin.store().smite().remove(id);
        restoreScale(p);
        hideHud(p);
    }

    private void flush(Player p) {
        UUID id = p.getUniqueId();
        double v = accum.getOrDefault(id, 0.0);
        if (v > 0) plugin.store().smite().put(id, v);
        else plugin.store().smite().remove(id);
        plugin.store().save();
    }

    // ---------- накопичення та використання ----------

    public void add(Player p, double amount) {
        UUID id = p.getUniqueId();
        double max = max();
        double cur = accum.getOrDefault(id, 0.0);
        if (cur >= max) return; // до використання Кари накопичення не росте
        double next = Math.min(max, cur + amount);
        accum.put(id, next);
        if (next >= max) {
            plugin.store().smite().put(id, next);
            plugin.store().save();
            plugin.msg().send(p, "smite-ready");
            plugin.fx().sound(p.getLocation(), "smite-ready", 1.0f, 1.0f);
            plugin.fx().spawn("smite-activate", p.getLocation().add(0, 1, 0), 40, 0.5, 1.0, 0.5, 0.1);
            tryScale(p);
        }
        updateHud(p);
    }

    /** Кара витрачена: накопичення скидається, розмір і HUD повертаються до початкового стану. */
    public void consume(Player p) {
        UUID id = p.getUniqueId();
        accum.remove(id);
        plugin.store().smite().remove(id);
        plugin.store().save();
        restoreScale(p);
        updateHud(p);
    }

    // ---------- HUD ----------

    public void updateHud(Player p) {
        UUID id = p.getUniqueId();
        if (!enabled() || !plugin.classes().isPaladin(id)) {
            hideHud(p);
            return;
        }
        double v = accum.getOrDefault(id, 0.0);
        double max = max();
        boolean ready = v >= max;
        if (!ready && v <= 0 && !plugin.getConfig().getBoolean("abilities.smite.hud-always-visible", true)) {
            hideHud(p);
            return;
        }
        Component title = ready
                ? plugin.msg().plain("hud-ready")
                : plugin.msg().plain("hud-title", "value", String.valueOf((int) Math.floor(v)),
                        "max", String.valueOf((int) Math.round(max)));
        float progress = (float) Math.max(0.0, Math.min(1.0, v / max));
        BossBar.Color color = ready ? BossBar.Color.WHITE : BossBar.Color.YELLOW;
        BossBar bar = bars.get(id);
        if (bar == null) {
            bar = BossBar.bossBar(title, progress, color, BossBar.Overlay.NOTCHED_10);
            bars.put(id, bar);
            p.showBossBar(bar);
        } else {
            bar.name(title);
            bar.progress(progress);
            bar.color(color);
        }
    }

    public void refreshHud(Player p) {
        hideHud(p);
        updateHud(p);
    }

    public void hideHud(Player p) {
        BossBar b = bars.remove(p.getUniqueId());
        if (b != null) p.hideBossBar(b);
    }

    public void updateAllHud() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (plugin.classes().isPaladin(p.getUniqueId())) refreshHud(p);
            else hideHud(p);
        }
    }

    // ---------- розмір ----------

    /** Чи вистачає місця над головою для збільшеного розміру (щоб не задихнутися в блоках). */
    private boolean hasHeadroom(Player p) {
        double s = scaleValue();
        if (s <= 1.0) return true;
        Location l = p.getLocation();
        return l.clone().add(0, 1.62 * s, 0).getBlock().isPassable()
                && l.clone().add(0, 1.8 * s, 0).getBlock().isPassable();
    }

    private void tryScale(Player p) {
        UUID id = p.getUniqueId();
        if (scaled.contains(id) || !hasHeadroom(p)) return;
        AttributeInstance a = p.getAttribute(Attribute.SCALE);
        if (a == null) return;
        a.setBaseValue(scaleValue());
        scaled.add(id);
    }

    private void restoreScale(Player p) {
        boolean was = scaled.remove(p.getUniqueId());
        AttributeInstance a = p.getAttribute(Attribute.SCALE);
        if (a == null) return;
        if (was || Math.abs(a.getBaseValue() - scaleValue()) < 1e-6) {
            a.setBaseValue(a.getDefaultValue());
        }
    }

    // ---------- аура ----------

    private void run() {
        tick++;
        double max = max();
        for (Map.Entry<UUID, Double> en : new ArrayList<>(accum.entrySet())) {
            if (en.getValue() < max) continue;
            UUID id = en.getKey();
            Player p = Bukkit.getPlayer(id);
            if (p == null || !p.isOnline() || p.isDead()) continue;

            boolean room = hasHeadroom(p);
            if (scaled.contains(id) && !room) restoreScale(p);
            else if (!scaled.contains(id) && room) tryScale(p);

            double s = scaled.contains(id) ? scaleValue() : 1.0;
            Location base = p.getLocation();
            for (int i = 0; i < 6; i++) {
                double a = tick * 0.5 + i * Math.PI / 3.0;
                double y = (0.2 + ((tick + i) % 8) * 0.25) * s;
                Location l = base.clone().add(Math.cos(a) * 0.7 * s, y, Math.sin(a) * 0.7 * s);
                plugin.fx().spawn("aura", l, 1, 0, 0, 0, 0);
            }
            plugin.fx().spawn("aura", base.clone().add(0, 1.0 * s, 0), 2, 0.4 * s, 0.8 * s, 0.4 * s, 0.01);
            if (tick % 10 == 0) plugin.fx().sound(base, "smite-aura", 0.4f, 1.6f);
        }
    }
}
