package ua.paladin.clazz;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import ua.paladin.PaladinPlugin;

import java.util.UUID;
import java.util.logging.Level;

/**
 * М'який зв'язок із плагіном BrawlerClass через рефлексію: PaladinClass компілюється
 * та працює і без нього, а коли він є — його клас показується в меню й керується звідси.
 */
public final class BrawlerLink {
    private static final String NAME = "BrawlerClass";

    private final PaladinPlugin plugin;
    private boolean failed;

    public BrawlerLink(PaladinPlugin plugin) { this.plugin = plugin; }

    private Plugin brawler() {
        if (failed) return null;
        Plugin pl = Bukkit.getPluginManager().getPlugin(NAME);
        return (pl != null && pl.isEnabled()) ? pl : null;
    }

    public boolean available() { return brawler() != null; }

    private void fail(Throwable t) {
        failed = true;
        plugin.getLogger().log(Level.WARNING,
                "Не вдалося зв'язатися з BrawlerClass (інша версія?). Інтеграцію вимкнено.", t);
    }

    public boolean isBrawler(Player p) {
        Plugin pl = brawler();
        if (pl == null) return false;
        try {
            Object dm = pl.getClass().getMethod("data").invoke(pl);
            Object pd = dm.getClass().getMethod("get", UUID.class).invoke(dm, p.getUniqueId());
            return Boolean.TRUE.equals(pd.getClass().getMethod("isBrawler").invoke(pd));
        } catch (Throwable t) {
            fail(t);
            return false;
        }
    }

    /** Робить гравця Кулачником (так само, як це робить меню BrawlerClass). */
    public boolean select(Player p) {
        return apply(p, true, false);
    }

    /** Скидає клас Кулачника й повертає предмети зі спец. слотів. */
    public boolean reset(Player p) {
        return apply(p, false, true);
    }

    private boolean apply(Player p, boolean value, boolean returnItems) {
        Plugin pl = brawler();
        if (pl == null) return false;
        try {
            UUID id = p.getUniqueId();
            Object dm = pl.getClass().getMethod("data").invoke(pl);
            Object pd = dm.getClass().getMethod("get", UUID.class).invoke(dm, id);
            if (returnItems) pl.getClass().getMethod("returnItems", Player.class).invoke(pl, p);
            pd.getClass().getMethod("setBrawler", boolean.class).invoke(pd, value);
            dm.getClass().getMethod("save", UUID.class).invoke(dm, id);
            pl.getClass().getMethod("onClassChanged", Player.class).invoke(pl, p);
            return true;
        } catch (Throwable t) {
            fail(t);
            return false;
        }
    }
}
