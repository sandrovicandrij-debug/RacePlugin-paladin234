package ua.paladin.clazz;

import org.bukkit.entity.Player;
import ua.paladin.PaladinPlugin;

import java.util.UUID;

/** Вибір класу: Паладін або Кулачник (з BrawlerClass), не одночасно. */
public final class ClassManager {
    private final PaladinPlugin plugin;

    public ClassManager(PaladinPlugin plugin) { this.plugin = plugin; }

    public boolean isPaladin(UUID id) { return plugin.store().paladins().contains(id); }

    public void selectPaladin(Player p) {
        UUID id = p.getUniqueId();
        if (isPaladin(id)) {
            plugin.msg().send(p, "class-already-paladin");
            return;
        }
        if (plugin.brawler().isBrawler(p) && plugin.brawler().reset(p)) {
            plugin.msg().send(p, "brawler-reset-for-paladin");
        }
        // Паладін не може бути союзником у чужій команді
        plugin.teams().removeMember(p, false);
        plugin.store().paladins().add(id);
        plugin.store().save();
        plugin.smite().onClassGained(p);
        plugin.msg().send(p, "class-selected-paladin");
        plugin.fx().sound(p.getLocation(), "blessing", 0.8f, 1.2f);
    }

    public void selectBrawler(Player p) {
        if (!plugin.brawler().available()) {
            plugin.msg().send(p, "brawler-missing");
            return;
        }
        if (plugin.brawler().isBrawler(p)) {
            plugin.msg().send(p, "class-already-brawler");
            return;
        }
        if (isPaladin(p.getUniqueId())) clear(p, false);
        if (plugin.brawler().select(p)) {
            plugin.msg().send(p, "class-selected-brawler");
        }
    }

    /** Скидає будь-який клас гравця. */
    public void resetAny(Player p) {
        boolean did = false;
        if (isPaladin(p.getUniqueId())) {
            clear(p, true);
            did = true;
        }
        if (plugin.brawler().isBrawler(p) && plugin.brawler().reset(p)) {
            plugin.msg().send(p, "class-reset");
            did = true;
        }
        if (!did) plugin.msg().send(p, "no-class");
    }

    /** Прибирає клас Паладіна: команда розпускається, візуальні ефекти вимикаються. */
    public void clear(Player p, boolean announce) {
        UUID id = p.getUniqueId();
        if (!plugin.store().paladins().remove(id)) return;
        plugin.teams().disband(id);
        plugin.smite().onClassLost(p);
        plugin.store().save();
        if (announce) plugin.msg().send(p, "class-reset");
    }

    /**
     * Якщо у гравця раптом обидва класи (наприклад, він обрав Кулачника у власному меню
     * BrawlerClass), лишає один.
     */
    public void reconcile(Player p, boolean preferBrawler) {
        if (!isPaladin(p.getUniqueId()) || !plugin.brawler().isBrawler(p)) return;
        if (preferBrawler) {
            clear(p, false);
            plugin.msg().send(p, "paladin-dropped-for-brawler");
        } else if (plugin.brawler().reset(p)) {
            plugin.msg().send(p, "brawler-dropped-for-paladin");
        }
    }
}
