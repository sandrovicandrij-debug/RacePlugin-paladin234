package ua.paladin.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import ua.paladin.PaladinPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** /клас (також /paladinclass, /pclass): меню вибору класу або /клас паладін. */
public final class ClassCommand implements CommandExecutor, TabCompleter {
    private static final List<String> OPTIONS = List.of("паладін", "кулачник", "скинути", "paladin", "brawler", "reset");

    private final PaladinPlugin plugin;

    public ClassCommand(PaladinPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            plugin.msg().send(sender, "player-only");
            return true;
        }
        if (args.length == 0) {
            plugin.menus().openHub(p);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "паладін", "паладин", "paladin" -> plugin.classes().selectPaladin(p);
            case "кулачник", "brawler" -> plugin.classes().selectBrawler(p);
            case "скинути", "reset", "clear" -> plugin.classes().resetAny(p);
            default -> plugin.msg().send(p, "usage-class");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length != 1) return out;
        String start = args[0].toLowerCase(Locale.ROOT);
        for (String o : OPTIONS) if (o.startsWith(start)) out.add(o);
        return out;
    }
}
