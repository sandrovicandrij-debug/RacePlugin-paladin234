package ua.paladin.command;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import ua.paladin.PaladinPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** /paladin: меню команди та підкоманди invite, accept, deny, leave, info, reload. */
public final class PaladinCommand implements CommandExecutor, TabCompleter {
    private final PaladinPlugin plugin;

    public PaladinCommand(PaladinPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("paladin.admin")) {
                plugin.msg().send(sender, "no-permission");
                return true;
            }
            plugin.reloadAll();
            plugin.msg().send(sender, "reloaded");
            return true;
        }
        if (!(sender instanceof Player p)) {
            plugin.msg().send(sender, "player-only");
            return true;
        }
        if (args.length == 0) {
            plugin.menus().openTeam(p);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "invite" -> {
                if (args.length < 2) {
                    plugin.msg().send(p, "usage-paladin");
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    plugin.msg().send(p, "player-not-found");
                    return true;
                }
                plugin.teams().invite(p, target);
            }
            case "accept" -> plugin.teams().accept(p);
            case "deny" -> plugin.teams().deny(p);
            case "leave" -> plugin.teams().leave(p);
            case "info" -> info(p);
            default -> plugin.msg().send(p, "usage-paladin");
        }
        return true;
    }

    private void info(Player p) {
        UUID leader = plugin.teams().teamOf(p.getUniqueId());
        if (leader == null) {
            plugin.msg().send(p, "no-team");
            return;
        }
        plugin.msg().send(p, "info-header");
        plugin.msg().send(p, "info-leader", "name", plugin.teams().name(leader));
        int max = plugin.teams().maxAllies();
        List<UUID> allies = new ArrayList<>(plugin.teams().members(leader));
        for (int i = 0; i < max; i++) {
            if (i < allies.size()) plugin.msg().send(p, "info-ally", "name", plugin.teams().name(allies.get(i)));
            else plugin.msg().send(p, "info-empty");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            String start = args[0].toLowerCase(Locale.ROOT);
            List<String> subs = new ArrayList<>(List.of("invite", "accept", "deny", "leave", "info"));
            if (sender.hasPermission("paladin.admin")) subs.add("reload");
            for (String s : subs) if (s.startsWith(start)) out.add(s);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("invite") && sender instanceof Player me) {
            String start = args[1].toLowerCase(Locale.ROOT);
            for (Player o : Bukkit.getOnlinePlayers()) {
                UUID id = o.getUniqueId();
                if (o.equals(me) || plugin.teams().inTeam(id) || plugin.classes().isPaladin(id)) continue;
                if (o.getName().toLowerCase(Locale.ROOT).startsWith(start)) out.add(o.getName());
            }
        }
        return out;
    }
}
