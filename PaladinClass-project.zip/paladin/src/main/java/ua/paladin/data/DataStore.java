package ua.paladin.data;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import ua.paladin.PaladinPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;

/** Сховище plugins/PaladinClass/data.yml: класи, команди, накопичена Кара. */
public final class DataStore {
    private final PaladinPlugin plugin;
    private final File file;
    private final Set<UUID> paladins = new HashSet<>();
    private final Map<UUID, Set<UUID>> teams = new LinkedHashMap<>();
    private final Map<UUID, Double> smite = new HashMap<>();

    public DataStore(PaladinPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
    }

    /** Гравці з класом Паладін. */
    public Set<UUID> paladins() { return paladins; }

    /** Команди: лідер -> союзники. */
    public Map<UUID, Set<UUID>> teams() { return teams; }

    /** Накопичена шкода Кари (зберігається між входами). */
    public Map<UUID, Double> smite() { return smite; }

    public void load() {
        paladins.clear();
        teams.clear();
        smite.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);

        ConfigurationSection cs = y.getConfigurationSection("classes");
        if (cs != null) {
            for (String k : cs.getKeys(false)) {
                UUID id = parse(k);
                if (id != null && "paladin".equalsIgnoreCase(cs.getString(k))) paladins.add(id);
            }
        }
        ConfigurationSection ts = y.getConfigurationSection("teams");
        if (ts != null) {
            for (String k : ts.getKeys(false)) {
                UUID leader = parse(k);
                if (leader == null) continue;
                Set<UUID> members = new LinkedHashSet<>();
                for (String s : ts.getStringList(k)) {
                    UUID id = parse(s);
                    if (id != null) members.add(id);
                }
                teams.put(leader, members);
            }
        }
        ConfigurationSection ss = y.getConfigurationSection("smite");
        if (ss != null) {
            for (String k : ss.getKeys(false)) {
                UUID id = parse(k);
                if (id != null) smite.put(id, ss.getDouble(k));
            }
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (UUID id : paladins) y.set("classes." + id, "paladin");
        for (Map.Entry<UUID, Set<UUID>> e : teams.entrySet()) {
            List<String> l = new ArrayList<>();
            for (UUID m : e.getValue()) l.add(m.toString());
            y.set("teams." + e.getKey(), l);
        }
        for (Map.Entry<UUID, Double> e : smite.entrySet()) {
            if (e.getValue() > 0) y.set("smite." + e.getKey(), e.getValue());
        }
        try {
            if (!plugin.getDataFolder().exists() && !plugin.getDataFolder().mkdirs()) {
                plugin.getLogger().warning("Не вдалося створити папку плагіна");
            }
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Не вдалося зберегти data.yml", ex);
        }
    }

    private static UUID parse(String s) {
        try {
            return UUID.fromString(s);
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }
}
