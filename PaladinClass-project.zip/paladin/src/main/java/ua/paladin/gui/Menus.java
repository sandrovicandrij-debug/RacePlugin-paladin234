package ua.paladin.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import ua.paladin.PaladinPlugin;
import ua.paladin.util.Items;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/** Усі меню: вибір класу (/клас), команда Паладіна (/paladin) та вибір гравця для запрошення. */
public final class Menus implements Listener {
    private enum Type { HUB, TEAM, INVITE }

    private static final class Holder implements InventoryHolder {
        final Type type;
        Inventory inv;
        final List<UUID> targets = new ArrayList<>();

        Holder(Type type) { this.type = type; }

        @Override
        public Inventory getInventory() { return inv; }
    }

    // Меню вибору класу
    private static final int HUB_PALADIN = 11;
    private static final int HUB_BRAWLER = 13;
    private static final int HUB_RESET = 15;
    // Меню команди
    private static final int TEAM_INVITE = 10;
    private static final int TEAM_SLOT_0 = 12;
    private static final int TEAM_LEAVE = 16;
    // Меню запрошення
    private static final int INVITE_BACK = 49;

    private final PaladinPlugin plugin;

    public Menus(PaladinPlugin plugin) { this.plugin = plugin; }

    private static void fill(Inventory inv) {
        for (int i = 0; i < inv.getSize(); i++) {
            inv.setItem(i, Items.icon(Material.GRAY_STAINED_GLASS_PANE, "&7 ", false));
        }
    }

    // ---------- вибір класу ----------

    public void openHub(Player p) {
        Holder h = new Holder(Type.HUB);
        Inventory inv = Bukkit.createInventory(h, 27, Component.text("Вибір класу"));
        h.inv = inv;
        renderHub(inv, p);
        p.openInventory(inv);
    }

    private void renderHub(Inventory inv, Player p) {
        fill(inv);
        boolean pal = plugin.classes().isPaladin(p.getUniqueId());
        inv.setItem(HUB_PALADIN, Items.icon(Material.SHIELD, "&6&lПаладін", pal,
                "&7Святий воїн, що береже союзників.",
                "&7",
                "&eЗдібності:",
                "&7- Священний захист (щит у лівій руці)",
                "&7- Благословення (спільні позитивні ефекти)",
                "&7- Кара (накопичена шкода -> потужний удар)",
                "&7",
                pal ? "&aВи вже обрали цей клас" : "&aНатисніть, щоб обрати"));

        if (plugin.brawler().available()) {
            boolean br = plugin.brawler().isBrawler(p);
            inv.setItem(HUB_BRAWLER, Items.icon(Material.NETHERITE_INGOT, "&6&lКулачник", br,
                    "&7Клас із плагіна BrawlerClass.",
                    "&7Б'є кулаками з характеристиками зброї",
                    "&7зі спеціального слота (/brawler).",
                    "&7",
                    br ? "&aВи вже обрали цей клас" : "&aНатисніть, щоб обрати"));
        } else {
            inv.setItem(HUB_BRAWLER, Items.icon(Material.GRAY_DYE, "&8Кулачник", false,
                    "&7Плагін BrawlerClass не встановлено",
                    "&7або вимкнено."));
        }
        inv.setItem(HUB_RESET, Items.icon(Material.BARRIER, "&cСкинути клас", false,
                "&7Прибирає ваш поточний клас."));
    }

    // ---------- меню команди ----------

    public void openTeam(Player p) {
        UUID id = p.getUniqueId();
        boolean paladin = plugin.classes().isPaladin(id);
        if (!paladin && !plugin.teams().inTeam(id)) {
            plugin.msg().send(p, "not-paladin");
            return;
        }
        Holder h = new Holder(Type.TEAM);
        Inventory inv = Bukkit.createInventory(h, 27, Component.text("Команда Паладіна"));
        h.inv = inv;
        renderTeam(inv, p);
        p.openInventory(inv);
    }

    private void renderTeam(Inventory inv, Player p) {
        fill(inv);
        UUID id = p.getUniqueId();
        boolean paladin = plugin.classes().isPaladin(id);
        UUID leader = plugin.teams().teamOf(id);
        if (leader == null) leader = id; // Паладін ще без команди
        int max = plugin.teams().maxAllies();
        List<UUID> allies = new ArrayList<>(plugin.teams().members(leader));

        if (paladin) {
            inv.setItem(TEAM_INVITE, Items.icon(Material.WRITABLE_BOOK, "&aЗапросити гравця", false,
                    "&7Союзників: &f" + allies.size() + "&7/&f" + max,
                    "&7Запрошення діє обмежений час.",
                    "&7",
                    "&eНатисніть, щоб обрати гравця"));
        } else {
            inv.setItem(TEAM_INVITE, Items.icon(Material.BOOK, "&7Запрошення", false,
                    "&7Запрошувати може лише Паладін."));
        }

        inv.setItem(TEAM_SLOT_0, Items.head(Bukkit.getOfflinePlayer(leader), "&6Паладін: &f" + plugin.teams().name(leader),
                "&7Лідер команди"));
        for (int i = 0; i < max && i < 2; i++) {
            int slot = TEAM_SLOT_0 + 1 + i;
            if (i < allies.size()) {
                UUID a = allies.get(i);
                inv.setItem(slot, Items.head(Bukkit.getOfflinePlayer(a), "&fСоюзник: &e" + plugin.teams().name(a),
                        Bukkit.getPlayer(a) != null ? "&aОнлайн" : "&7Офлайн"));
            } else {
                inv.setItem(slot, Items.icon(Material.LIGHT_GRAY_STAINED_GLASS_PANE, "&7Вільне місце", false));
            }
        }
        if (max > 2) {
            // Якщо в конфігу більше союзників, ніж слотів у ряду, показуємо підсумок
            inv.setItem(TEAM_SLOT_0 + 3, Items.icon(Material.PAPER, "&7Усього союзників: &f" + allies.size() + "&7/&f" + max, false));
        }

        if (plugin.teams().isLeader(id)) {
            inv.setItem(TEAM_LEAVE, Items.icon(Material.TNT, "&cРозпустити команду", false,
                    "&7Усі союзники втратять захист."));
        } else if (plugin.teams().inTeam(id)) {
            inv.setItem(TEAM_LEAVE, Items.icon(Material.OAK_DOOR, "&cПокинути команду", false));
        } else {
            inv.setItem(TEAM_LEAVE, Items.icon(Material.OAK_DOOR, "&8Покинути команду", false,
                    "&7Ви ще не маєте команди."));
        }
    }

    // ---------- запрошення ----------

    public void openInvite(Player p) {
        if (!plugin.classes().isPaladin(p.getUniqueId())) {
            plugin.msg().send(p, "not-paladin");
            return;
        }
        Holder h = new Holder(Type.INVITE);
        Inventory inv = Bukkit.createInventory(h, 54, Component.text("Запросити гравця"));
        h.inv = inv;

        List<Player> candidates = new ArrayList<>();
        for (Player o : Bukkit.getOnlinePlayers()) {
            UUID oid = o.getUniqueId();
            if (o.equals(p) || plugin.teams().inTeam(oid) || plugin.classes().isPaladin(oid)) continue;
            candidates.add(o);
        }
        candidates.sort(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER));
        for (int i = 0; i < candidates.size() && i < 45; i++) {
            Player o = candidates.get(i);
            h.targets.add(o.getUniqueId());
            inv.setItem(i, Items.head(o, "&f" + o.getName(), "&aНатисніть, щоб запросити"));
        }
        inv.setItem(INVITE_BACK, Items.icon(Material.ARROW, "&7Назад", false));
        p.openInventory(inv);
    }

    // ---------- обробка кліків ----------

    @EventHandler(priority = EventPriority.LOWEST)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true); // предмети меню взяти неможливо
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != h.inv) return;
        int slot = e.getRawSlot();
        switch (h.type) {
            case HUB -> clickHub(p, h, slot);
            case TEAM -> clickTeam(p, h, slot);
            case INVITE -> clickInvite(p, h, slot);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    private void clickHub(Player p, Holder h, int slot) {
        if (slot == HUB_PALADIN) plugin.classes().selectPaladin(p);
        else if (slot == HUB_BRAWLER) plugin.classes().selectBrawler(p);
        else if (slot == HUB_RESET) plugin.classes().resetAny(p);
        else return;
        renderHub(h.inv, p);
    }

    private void clickTeam(Player p, Holder h, int slot) {
        if (slot == TEAM_INVITE) {
            Bukkit.getScheduler().runTask(plugin, () -> openInvite(p));
        } else if (slot == TEAM_LEAVE) {
            plugin.teams().leave(p);
            if (plugin.teams().inTeam(p.getUniqueId()) || plugin.classes().isPaladin(p.getUniqueId())) {
                renderTeam(h.inv, p);
            } else {
                Bukkit.getScheduler().runTask(plugin, p::closeInventory);
            }
        }
    }

    private void clickInvite(Player p, Holder h, int slot) {
        if (slot == INVITE_BACK) {
            Bukkit.getScheduler().runTask(plugin, () -> openTeam(p));
            return;
        }
        if (slot < 0 || slot >= h.targets.size()) return;
        Player target = Bukkit.getPlayer(h.targets.get(slot));
        Bukkit.getScheduler().runTask(plugin, p::closeInventory);
        if (target == null) {
            plugin.msg().send(p, "player-not-found");
            return;
        }
        plugin.teams().invite(p, target);
    }
}
