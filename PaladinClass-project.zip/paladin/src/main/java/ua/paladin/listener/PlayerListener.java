package ua.paladin.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import ua.paladin.PaladinPlugin;

/** Вхід, вихід, смерть, респавн; контроль «один клас» разом із BrawlerClass. */
public final class PlayerListener implements Listener {
    /** Холдер меню /class плагіна BrawlerClass (порівнюємо за назвою класу — залежності немає). */
    private static final String BRAWLER_MENU_HOLDER = "ua.brawler.gui.ClassMenu$Holder";

    private final PaladinPlugin plugin;

    public PlayerListener(PaladinPlugin plugin) { this.plugin = plugin; }

    public void handleJoin(Player p) {
        plugin.classes().reconcile(p, false);
        plugin.smite().onJoin(p);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) { handleJoin(e.getPlayer()); }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        plugin.teams().onQuit(p.getUniqueId());
        plugin.smite().onQuit(p);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent e) {
        plugin.smite().onDeath(e.getEntity());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline()) plugin.smite().refreshHud(p);
        });
    }

    /** Гравець закрив меню Кулачника: якщо він обрав його там, Паладін скидається. */
    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player p)) return;
        if (e.getInventory().getHolder() == null) return;
        if (!e.getInventory().getHolder().getClass().getName().equals(BRAWLER_MENU_HOLDER)) return;
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (p.isOnline()) plugin.classes().reconcile(p, true);
        });
    }
}
