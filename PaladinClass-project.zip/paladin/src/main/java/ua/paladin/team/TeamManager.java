package ua.paladin.team;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import ua.paladin.PaladinPlugin;
import ua.paladin.data.DataStore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Команди Паладіна: лідер + союзники, запрошення з обмеженим часом дії. */
public final class TeamManager {
    private static final class Invite {
        final UUID leader;
        final long expiresAt;
        BukkitTask task;

        Invite(UUID leader, long expiresAt) {
            this.leader = leader;
            this.expiresAt = expiresAt;
        }
    }

    private final PaladinPlugin plugin;
    private final Map<UUID, UUID> memberToLeader = new HashMap<>();
    private final Map<UUID, Invite> invites = new HashMap<>(); // за гравцем, якого запрошено

    public TeamManager(PaladinPlugin plugin) { this.plugin = plugin; }

    public int maxAllies() { return Math.max(1, plugin.getConfig().getInt("team.max-allies", 2)); }

    /** Завантаження та очищення від застарілих/некоректних записів. */
    public void load() {
        DataStore st = plugin.store();
        memberToLeader.clear();
        boolean changed = false;
        int max = maxAllies();
        Iterator<Map.Entry<UUID, Set<UUID>>> it = st.teams().entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Set<UUID>> e = it.next();
            UUID leader = e.getKey();
            if (!st.paladins().contains(leader) || memberToLeader.containsKey(leader)) {
                it.remove();
                changed = true;
                continue;
            }
            int count = 0;
            Iterator<UUID> mi = e.getValue().iterator();
            while (mi.hasNext()) {
                UUID m = mi.next();
                boolean bad = m.equals(leader) || memberToLeader.containsKey(m)
                        || st.teams().containsKey(m) || st.paladins().contains(m) || count >= max;
                if (bad) {
                    mi.remove();
                    changed = true;
                } else {
                    memberToLeader.put(m, leader);
                    count++;
                }
            }
        }
        if (changed) st.save();
    }

    // ---------- запити ----------

    public boolean isLeader(UUID id) { return plugin.store().teams().containsKey(id); }

    public UUID leaderOf(UUID member) { return memberToLeader.get(member); }

    public boolean inTeam(UUID id) { return isLeader(id) || memberToLeader.containsKey(id); }

    /** Ідентифікатор команди (UUID лідера) або null. */
    public UUID teamOf(UUID id) {
        if (isLeader(id)) return id;
        return memberToLeader.get(id);
    }

    public boolean sameTeam(UUID a, UUID b) {
        UUID ta = teamOf(a);
        return ta != null && ta.equals(teamOf(b));
    }

    public Set<UUID> members(UUID leader) {
        Set<UUID> m = plugin.store().teams().get(leader);
        return m == null ? new LinkedHashSet<>() : m;
    }

    public List<Player> onlineMembers(UUID leader) {
        List<Player> out = new ArrayList<>();
        Set<UUID> m = plugin.store().teams().get(leader);
        if (m == null) return out;
        for (UUID id : m) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && p.isOnline()) out.add(p);
        }
        return out;
    }

    private int pendingFrom(UUID leader) {
        int n = 0;
        for (Invite i : invites.values()) if (i.leader.equals(leader)) n++;
        return n;
    }

    // ---------- запрошення ----------

    public void invite(Player leader, Player target) {
        UUID lid = leader.getUniqueId();
        UUID tid = target.getUniqueId();
        if (!plugin.classes().isPaladin(lid)) {
            plugin.msg().send(leader, "not-paladin");
            return;
        }
        if (lid.equals(tid)) {
            plugin.msg().send(leader, "invite-self");
            return;
        }
        if (memberToLeader.containsKey(lid)) {
            plugin.msg().send(leader, "in-other-team");
            return;
        }
        if (plugin.classes().isPaladin(tid)) {
            plugin.msg().send(leader, "target-is-paladin", "player", target.getName());
            return;
        }
        if (inTeam(tid)) {
            plugin.msg().send(leader, "target-in-team", "player", target.getName());
            return;
        }
        Invite existing = invites.get(tid);
        if (existing != null && existing.leader.equals(lid)) {
            plugin.msg().send(leader, "invite-pending", "player", target.getName());
            return;
        }
        Set<UUID> members = plugin.store().teams().get(lid);
        int size = members == null ? 0 : members.size();
        if (size + pendingFrom(lid) >= maxAllies()) {
            plugin.msg().send(leader, "team-full");
            return;
        }
        if (members == null) {
            plugin.store().teams().put(lid, new LinkedHashSet<>());
            plugin.store().save();
            plugin.msg().send(leader, "team-created");
            plugin.fx().sound(leader.getLocation(), "team", 0.8f, 1.2f);
        }

        cancelInvite(tid); // старе запрошення від іншого Паладіна замінюється
        int seconds = Math.max(5, plugin.getConfig().getInt("team.invite-timeout-seconds", 60));
        Invite inv = new Invite(lid, System.currentTimeMillis() + seconds * 1000L);
        inv.task = Bukkit.getScheduler().runTaskLater(plugin, () -> expire(tid), seconds * 20L);
        invites.put(tid, inv);

        String secs = String.valueOf(seconds);
        plugin.msg().send(leader, "invite-sent", "player", target.getName(), "seconds", secs);

        Component accept = Component.text("[ПРИЙНЯТИ]", NamedTextColor.GREEN)
                .clickEvent(ClickEvent.runCommand("/paladin accept"))
                .hoverEvent(HoverEvent.showText(Component.text("Прийняти запрошення")));
        Component deny = Component.text("[ВІДХИЛИТИ]", NamedTextColor.RED)
                .clickEvent(ClickEvent.runCommand("/paladin deny"))
                .hoverEvent(HoverEvent.showText(Component.text("Відхилити запрошення")));
        target.sendMessage(plugin.msg().component("invite-received", "leader", leader.getName(), "seconds", secs)
                .append(Component.space()).append(accept)
                .append(Component.space()).append(deny));
        plugin.fx().sound(target.getLocation(), "team", 0.8f, 1.0f);
    }

    public void accept(Player p) {
        UUID id = p.getUniqueId();
        Invite inv = invites.get(id);
        if (inv == null || System.currentTimeMillis() > inv.expiresAt) {
            cancelInvite(id);
            plugin.msg().send(p, "no-invite");
            return;
        }
        cancelInvite(id);
        UUID lid = inv.leader;
        Set<UUID> members = plugin.store().teams().get(lid);
        if (members == null || !plugin.classes().isPaladin(lid) || inTeam(id) || plugin.classes().isPaladin(id)) {
            plugin.msg().send(p, "invite-invalid");
            return;
        }
        if (members.size() >= maxAllies()) {
            plugin.msg().send(p, "team-full-target");
            return;
        }
        members.add(id);
        memberToLeader.put(id, lid);
        plugin.store().save();

        Player leader = Bukkit.getPlayer(lid);
        String leaderName = leader != null ? leader.getName() : name(lid);
        plugin.msg().send(p, "invite-accepted-target", "leader", leaderName);
        plugin.fx().sound(p.getLocation(), "team", 0.8f, 1.4f);
        if (leader != null) {
            plugin.msg().send(leader, "invite-accepted-leader", "player", p.getName());
            plugin.fx().sound(leader.getLocation(), "team", 0.8f, 1.4f);
        }
    }

    public void deny(Player p) {
        UUID id = p.getUniqueId();
        Invite inv = invites.get(id);
        if (inv == null) {
            plugin.msg().send(p, "no-invite");
            return;
        }
        cancelInvite(id);
        plugin.msg().send(p, "invite-denied-target");
        Player leader = Bukkit.getPlayer(inv.leader);
        if (leader != null) plugin.msg().send(leader, "invite-denied-leader", "player", p.getName());
    }

    private void expire(UUID tid) {
        Invite inv = invites.remove(tid);
        if (inv == null) return;
        Player target = Bukkit.getPlayer(tid);
        Player leader = Bukkit.getPlayer(inv.leader);
        String targetName = target != null ? target.getName() : name(tid);
        String leaderName = leader != null ? leader.getName() : name(inv.leader);
        if (target != null) plugin.msg().send(target, "invite-expired-target", "leader", leaderName);
        if (leader != null) plugin.msg().send(leader, "invite-expired-leader", "player", targetName);
    }

    private void cancelInvite(UUID tid) {
        Invite inv = invites.remove(tid);
        if (inv != null && inv.task != null) inv.task.cancel();
    }

    // ---------- вихід, розпуск ----------

    /** Вихід із команди. Для лідера означає розпуск. */
    public void leave(Player p) {
        UUID id = p.getUniqueId();
        if (isLeader(id)) {
            disband(id);
            return;
        }
        if (!removeMember(p, true)) plugin.msg().send(p, "no-team");
    }

    /** Прибирає союзника з команди. Повертає false, якщо він не був союзником. */
    public boolean removeMember(Player p, boolean notify) {
        UUID id = p.getUniqueId();
        UUID lid = memberToLeader.remove(id);
        if (lid == null) return false;
        Set<UUID> m = plugin.store().teams().get(lid);
        if (m != null) m.remove(id);
        plugin.store().save();
        if (notify) {
            plugin.msg().send(p, "team-left");
            Player leader = Bukkit.getPlayer(lid);
            if (leader != null) plugin.msg().send(leader, "team-left-notify", "player", p.getName());
        }
        return true;
    }

    /** Розпускає команду лідера (якщо вона є). */
    public void disband(UUID leader) {
        Set<UUID> members = plugin.store().teams().remove(leader);
        for (UUID tid : new ArrayList<>(invites.keySet())) {
            Invite i = invites.get(tid);
            if (i != null && i.leader.equals(leader)) cancelInvite(tid);
        }
        if (members == null) return;
        for (UUID m : members) {
            memberToLeader.remove(m);
            Player mp = Bukkit.getPlayer(m);
            if (mp != null) plugin.msg().send(mp, "team-disbanded");
        }
        plugin.store().save();
        Player lp = Bukkit.getPlayer(leader);
        if (lp != null) plugin.msg().send(lp, "team-disbanded-leader");
    }

    /** Очищення тимчасових даних при виході гравця з сервера. */
    public void onQuit(UUID id) {
        cancelInvite(id);
        for (UUID tid : new ArrayList<>(invites.keySet())) {
            Invite i = invites.get(tid);
            if (i != null && i.leader.equals(id)) cancelInvite(tid);
        }
    }

    public void shutdown() {
        for (UUID tid : new ArrayList<>(invites.keySet())) cancelInvite(tid);
    }

    public String name(UUID id) {
        String n = Bukkit.getOfflinePlayer(id).getName();
        return n != null ? n : id.toString().substring(0, 8);
    }
}
