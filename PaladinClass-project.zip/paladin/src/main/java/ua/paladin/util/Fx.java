package ua.paladin.util;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import ua.paladin.PaladinPlugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Частинки та звуки, що налаштовуються в config.yml. */
public final class Fx {
    private static final Particle.DustOptions GOLD = new Particle.DustOptions(Color.fromRGB(255, 215, 0), 1.2f);

    private final PaladinPlugin plugin;
    private final Map<String, List<Particle>> groups = new HashMap<>();

    public Fx(PaladinPlugin plugin) { this.plugin = plugin; }

    public void reload() {
        groups.clear();
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("particles");
        if (s == null) return;
        for (String k : s.getKeys(false)) {
            if (!s.isList(k)) continue;
            List<Particle> l = new ArrayList<>();
            for (String n : s.getStringList(k)) {
                try {
                    l.add(Particle.valueOf(n.trim().toUpperCase(Locale.ROOT)));
                } catch (IllegalArgumentException ex) {
                    plugin.getLogger().warning("Невідома частинка '" + n + "' у particles." + k);
                }
            }
            groups.put(k, l);
        }
    }

    public void spawn(String group, Location loc, int count, double dx, double dy, double dz, double speed) {
        if (!plugin.getConfig().getBoolean("particles.enabled", true)) return;
        World w = loc.getWorld();
        if (w == null) return;
        List<Particle> l = groups.get(group);
        if (l == null) return;
        for (Particle p : l) {
            Class<?> type = p.getDataType();
            if (type == Void.class) {
                w.spawnParticle(p, loc, count, dx, dy, dz, speed);
            } else if (type == Particle.DustOptions.class) {
                w.spawnParticle(p, loc, count, dx, dy, dz, speed, GOLD);
            }
        }
    }

    /** Лінія частинок між двома точками. */
    public void line(String group, Location from, Location to, int points) {
        if (from.getWorld() == null || !from.getWorld().equals(to.getWorld())) return;
        for (int i = 0; i <= points; i++) {
            double t = (double) i / points;
            Location l = new Location(from.getWorld(),
                    from.getX() + (to.getX() - from.getX()) * t,
                    from.getY() + (to.getY() - from.getY()) * t,
                    from.getZ() + (to.getZ() - from.getZ()) * t);
            spawn(group, l, 1, 0, 0, 0, 0);
        }
    }

    public void sound(Location l, String key, float volume, float pitch) {
        if (!plugin.getConfig().getBoolean("sounds.enabled", true)) return;
        String sound = plugin.getConfig().getString("sounds." + key, "");
        if (sound == null || sound.isEmpty()) return;
        World w = l.getWorld();
        if (w == null) return;
        float vol = volume * (float) plugin.getConfig().getDouble("sounds.volume", 1.0);
        w.playSound(l, sound, SoundCategory.PLAYERS, vol, pitch);
    }
}
