package ua.paladin.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;

public final class Items {
    private static final LegacyComponentSerializer LEG = LegacyComponentSerializer.legacyAmpersand();

    private Items() {}

    public static Component plain(String legacy) {
        return LEG.deserialize(legacy).decoration(TextDecoration.ITALIC, false);
    }

    private static List<Component> lore(String... lines) {
        List<Component> l = new ArrayList<>();
        for (String s : lines) l.add(plain(s));
        return l;
    }

    public static ItemStack icon(Material m, String name, boolean glow, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(plain(name));
        meta.lore(lore(lore));
        if (glow) meta.setEnchantmentGlintOverride(true);
        it.setItemMeta(meta);
        return it;
    }

    public static ItemStack head(OfflinePlayer owner, String name, String... lore) {
        ItemStack it = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) it.getItemMeta();
        meta.setOwningPlayer(owner);
        meta.displayName(plain(name));
        meta.lore(lore(lore));
        it.setItemMeta(meta);
        return it;
    }
}
