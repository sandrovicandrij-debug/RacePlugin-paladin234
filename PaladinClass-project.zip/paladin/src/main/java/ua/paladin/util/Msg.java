package ua.paladin.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import ua.paladin.PaladinPlugin;

public final class Msg {
    private static final LegacyComponentSerializer LEG = LegacyComponentSerializer.legacyAmpersand();
    private final PaladinPlugin plugin;

    public Msg(PaladinPlugin plugin) { this.plugin = plugin; }

    public String raw(String key, String... pairs) {
        String s = plugin.getConfig().getString("messages." + key, key);
        for (int i = 0; i + 1 < pairs.length; i += 2) s = s.replace("{" + pairs[i] + "}", pairs[i + 1]);
        return s;
    }

    /** Повідомлення з префіксом. */
    public Component component(String key, String... pairs) {
        String prefix = plugin.getConfig().getString("messages.prefix", "");
        return LEG.deserialize(prefix + raw(key, pairs));
    }

    /** Повідомлення без префікса (BossBar, ActionBar). */
    public Component plain(String key, String... pairs) {
        return LEG.deserialize(raw(key, pairs));
    }

    public void send(CommandSender to, String key, String... pairs) {
        to.sendMessage(component(key, pairs));
    }

    public void bar(Player p, String key, String... pairs) {
        p.sendActionBar(plain(key, pairs));
    }
}
