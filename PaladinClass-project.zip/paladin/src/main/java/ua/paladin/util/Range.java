package ua.paladin.util;

import org.bukkit.entity.Player;

public final class Range {
    private Range() {}

    /** Чи в межах радіуса (r <= 0 — без обмеження, але лише в одному світі). */
    public static boolean within(Player a, Player b, double r) {
        if (!a.getWorld().equals(b.getWorld())) return false;
        if (r <= 0) return true;
        return a.getLocation().distanceSquared(b.getLocation()) <= r * r;
    }
}
