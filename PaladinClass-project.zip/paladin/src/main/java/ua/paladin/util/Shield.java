package ua.paladin.util;

import org.bukkit.Material;
import org.bukkit.entity.Player;

public final class Shield {
    private Shield() {}

    /** Чи є щит у лівій руці. */
    public static boolean inOffHand(Player p) {
        return p.getInventory().getItemInOffHand().getType() == Material.SHIELD;
    }
}
